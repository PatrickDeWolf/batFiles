netsh wlan delete filter permission=denyall networktype=infrastructure
Stop-Process -processname powershell