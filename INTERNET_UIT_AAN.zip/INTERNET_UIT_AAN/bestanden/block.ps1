netsh wlan add filter permission=denyall networktype=infrastructure
Stop-Process -processname powershell